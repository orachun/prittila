#This version of bxSlider is now deprecated!
##Use bxSlider version 4.0 found [here](http://bxslider.com) and on [Github](https://github.com/wandoledzep/bxslider-4)

jQuery bxSlider v3.0
http://bxslider.com

Copyright 2011, Steven Wanderski
http://bxcreative.com

Free to use and abuse under the MIT license.
http://www.opensource.org/licenses/mit-license.php